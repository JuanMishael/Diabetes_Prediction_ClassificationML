source:
https://www.kaggle.com/code/shrutimechlearn/step-by-step-diabetes-classification-knn-detailed